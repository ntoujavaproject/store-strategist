# 餐廳分析器 v1.0.0 發布說明

## 🎉 新功能
- ✨ 全新的餐廳評論分析功能
- 🤖 整合 AI 聊天助手
- 📊 進階評分視覺化
- 🌍 跨平台支援

## 📦 下載選項

### 🌐 跨平台版本（推薦）
**檔案：** RestaurantAnalyzer-1.0.0-crossplatform.zip
- 適用於 Windows 10+, macOS 10.15+, Linux
- 包含自動環境設置腳本
- 檔案大小：~16MB

### 🍎 Mac 專用版本
**檔案：** RestaurantAnalyzer-1.0.0-mac.dmg
- 專為 macOS 最佳化
- 原生安裝體驗
- 檔案大小：~16MB

## 🎯 系統需求
- Java 21+ (必需)
- Python 3.8+ (可選，用於數據收集)
- 2GB RAM (建議)
- 300MB 磁碟空間

## 🔧 快速開始
1. 下載對應你系統的版本
2. 解壓縮或安裝
3. 執行啟動腳本
4. 首次啟動會自動設置環境

## 📞 技術支援
- 📖 查看 README.txt 獲取詳細說明
- 🐛 回報問題：[GitHub Issues](https://github.com/yourusername/restaurant-analyzer/issues)
- 📧 聯繫：your.email@example.com

---
發布日期：2025-05-29
