center_lat = 25.1494729
center_lon = 121.7641153
search_radius = 2000

project_id = "java2025-91d74"
comment_url = "https://www.google.com.tw/maps/rpc/listugcposts"
headers1 = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"
            "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36"}
headers2 = {"Content-Type": "application/json; charset=UTF-8"}

